﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerControler : NetworkBehaviour
{

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {

        if (!isLocalPlayer)
        {
            return;
        }

        var x = Input.GetAxis("Horizontal") * Time.deltaTime * 350.0f;
        var z = Input.GetAxis("Vertical") * Time.deltaTime * 8.0f;
	    var y = Input.GetAxis("Sidestep") * Time.deltaTime * 10.0f;
	    var air = Input.GetAxis("Jump") * Time.deltaTime * 10.0f;

        transform.Rotate(0, x, 0);
        transform.Translate(y, air, z);

    }

    public override void OnStartLocalPlayer()
    {
        GetComponent<MeshRenderer>().material.color = Color.red;
    }
}
