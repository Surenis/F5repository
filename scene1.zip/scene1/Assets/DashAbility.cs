﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class DashAbility : NetworkBehaviour { 
    private Vector2 GetInputVector () {
        Vector2 vector = Vector2.zero;
        bool up = Input.GetKey(KeyCode.W);
        bool down = Input.GetKey(KeyCode.S);
        bool left = Input.GetKey(KeyCode.A);
        bool right = Input.GetKey(KeyCode.D);
 
        if (up == true) {
            vector.y = 1;
        } else if (down == true) {
            vector.y = -1;
        }
 
        if (left == true) {
            vector.x = -1;
        } else if (right == true) {
            vector.x = 1;
        }
 
        return vector.normalized;
    }

   
    void Start()
    {
    }

    void Update()
    {
       
    }
}

